package com.nopcommerce;

public class AssignmentOperators {
    public static void main(String[] args) {
        int a=10;
        int b=20;
        int c;
        System.out.println(c=a);
        System.out.println(b+=a);
        System.out.println(b-=a);
        System.out.println(b*=a);
        System.out.println(b/=a);
        System.out.println(b%=a);
        System.out.println(b^=a);
    }
}
