package com.nopcommerce;

public class StaticAndNonStatic {
    String name;       //public
    static int salary;  //static

    public static void main(String[] args) {

        salary =25000;
        System.out.println(salary);
    }
}
