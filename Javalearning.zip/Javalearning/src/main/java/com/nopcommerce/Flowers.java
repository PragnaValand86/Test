package com.nopcommerce;

public class Flowers {
    public void Sunflowers() {
        System.out.println("Sunflowers is Summer Flowers");
    }

        public void lotus() {
            System.out.println("National Flower");
        }
        public void Orchid(){
        System.out.println("Orchid Flowers Bring Good luck");

        }

        }




