package com.nopcommerce.homepage;

public class Voting {



        public static void main(String[] args) {
            int vote=25;
            int vote1=17;


            if(vote>vote1){
                System.out.println("eligeble to vote");
            }
            else{
                System.out.println("not eligeble to vote");
            }
        }

    }

