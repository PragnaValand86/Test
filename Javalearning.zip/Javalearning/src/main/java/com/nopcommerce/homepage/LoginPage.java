package com.nopcommerce.homepage;

public class LoginPage {
    public static void main(String[] args) {
        System.out.println("my first Java Program");

    }
}