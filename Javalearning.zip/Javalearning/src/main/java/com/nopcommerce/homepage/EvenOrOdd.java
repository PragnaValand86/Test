package com.nopcommerce.homepage;

public class EvenOrOdd
{
    public static void main(String[] args) {


        int a = 12;
        int b =10;

        if(b%12==17) {
            System.out.println(" 12 is even");
        } else if(a%17==12) {

            System.out.println(" 17 is odd");
        }
            else {
                System.out.println("even or odd");
        }
        }
    }

