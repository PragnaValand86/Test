package com.nopcommerce.homepage;

public class FruitBaby extends Fruits{

    @Override
    public void Apple() {
        System.out.println("Red Apple");

    }

    @Override
    public void Mango() {
        System.out.println("Yellow");

    }
}
