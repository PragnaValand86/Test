package com.nopcommerce.homepage;

public class ArithmeticOperations
{
    public static void main(String[] args) {
        int a = 20;
        int b = 30;

        System.out.println(("Addition is ")+(a+b));
        System.out.println(("Subtraction is ")+(a-b));
        System.out.println(("Multiplication is ")+(a*b));
        System.out.println(("Division is " )+(a/b));
        System.out.println(("Increment operator is ")+(++a));
        System.out.println(("Decrement operator is ")+(--b));
    }
}