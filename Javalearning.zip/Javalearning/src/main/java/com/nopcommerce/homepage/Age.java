package com.nopcommerce.homepage;

public class Age
{
    public static void main(String[] args) {
        int v=18;


        if(v>17){
            System.out.println(" eligeble to vote");
        }
        else{
            System.out.println(" Not eligeble to vote");
        }
    }

}
