package com.nopcommerce.homepage;


public class  PositiveNegative
{
    public static void main(String[] args)
    {
        int num = 10;
        int num1 = -1;

        if (num1>num)
        {
            System.out.println(" 10 is Positive");
        }
        else if (num<num1) {
            System.out.print(" -1 is Negative");
        }
            else {
                System.out.println(" Not posituve or negative");
            }
        }
    }









