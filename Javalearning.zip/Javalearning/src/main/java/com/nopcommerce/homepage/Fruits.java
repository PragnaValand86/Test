package com.nopcommerce.homepage;

public class Fruits { // Parent Class

    public void Mango(){
        System.out.println("Mango is the summer fruit");
    }
    public void Apple(){
        System.out.println("An apple keeps Doctor away");
    }



}
