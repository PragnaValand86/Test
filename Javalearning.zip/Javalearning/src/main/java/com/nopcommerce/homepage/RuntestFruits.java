package com.nopcommerce.homepage;

public class RuntestFruits {
    public static void main(String[] args) {
        Fruits obj1 = new Fruits();
        obj1.Apple();
        obj1.Mango();
    }
}
