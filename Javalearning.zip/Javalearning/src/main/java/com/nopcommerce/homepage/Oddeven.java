package com.nopcommerce.homepage;

public class Oddeven
{
    public static void main(String[] args) {
        int a = 4;
        int b = 8;
        System.out.print(b%a);
    }
}



