package com.nopcommerce;

public class RuntestFlowers {
    public static void main(String[] args) {

        Flowers obj1 = new Flowers();
        obj1.Sunflowers();
        obj1.lotus();
        obj1.Orchid();



    }
}
