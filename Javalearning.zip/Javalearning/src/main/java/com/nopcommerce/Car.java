package com.nopcommerce;

public class Car {
    int mod;
    int wheel;

    public static void main(String[] args) {
        Car a = new Car();
        Car b = new Car();
        Car c = new Car();
        a.mod = 2019;
        a.wheel = 4;
        b.mod = 2020;
        b.wheel = 4;
        c.mod = 2021;
        c.wheel = 4;
    }
}
