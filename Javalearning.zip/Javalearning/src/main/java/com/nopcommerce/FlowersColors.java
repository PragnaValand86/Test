package com.nopcommerce;

public class FlowersColors extends Flowers {
    @Override
    public void Sunflowers() {
       System.out.println("Yellow");
    }

    @Override
    public void lotus() {
       System.out.println("Pink");
    }

    @Override
    public void Orchid() {
      System.out.println("Purple");
    }
}

