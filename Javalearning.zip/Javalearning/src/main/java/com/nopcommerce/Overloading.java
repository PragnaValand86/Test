package com.nopcommerce;

public class Overloading {
    static int plusMethod(int x, int y) {
        return x = y;
    }

        static double plusMethod(double x, double y){

        return x+y;
        }

    public static void main(String[] args) {


    }
    }

