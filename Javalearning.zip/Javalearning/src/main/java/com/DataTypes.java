package com;

public class DataTypes
{
    public static void main(String[] args) {
        int i = 10;
        double d = 20.5;
        char c = 'A';
        boolean b = true;

        System.out.println(i);
        System.out.println(d);
        System.out.println(c);
        System.out.println(!b);






    }
}
