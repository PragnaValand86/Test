public class ListofManualTesting {


    public static void main(String[] args){
        System.out.println("What Is Software");
        System.out.println("Software Risks");
        System.out.println("What Is Software Testing");
        System.out.println("What Is Manual Testing");
        System.out.println("SDLC");
        System.out.println("STLC");
        System.out.println("Principle Of Software Testing");
        System.out.println("Test Plan And Its Benefits");
        System.out.println("Testing Techniques");
        System.out.println("What Is Bug");
        System.out.println("Bug Lifecycle");
        System.out.println("Severity Vs Priority");
        System.out.println("Testing Levels");
        System.out.println("Software Development Models");
        System.out.println("TDD And BDD");

    }
}
