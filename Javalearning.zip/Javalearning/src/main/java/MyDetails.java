public class MyDetails {


    public static void main(String[] args) {
        System.out.print("Pragna ");
        System.out.println("Valand");
    }
}