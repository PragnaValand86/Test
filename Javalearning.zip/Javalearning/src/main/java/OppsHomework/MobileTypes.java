package OppsHomework;

public class MobileTypes extends Mobile {
}
