package OppsHomework;

public class MobileMake {
    public static void main(String[] args) {
        MobileFetures MT = new MobileFetures();
        MT.mbmake1();
        MT.mbmake2();
        MT.mbmake3();


    }
}
