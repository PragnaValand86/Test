package OppsHomework;

public class MobileFetures {
    public void mbmake1(){
        System.out.println("Made in China");
    }
    public void mbmake2(){
        System.out.println("Made in India");
    }
    public void mbmake3(){
        System.out.println("Made in Japan");
    }
}
