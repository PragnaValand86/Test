package org;

public class DoWhileTablesOf8 {
    public static void main(String[] args) {
        int x = 8;
        int y = 1;
        do {
            System.out.println(x + "*" + "=" + y);
            y++;
        } while(y<=8);
        }
    }


