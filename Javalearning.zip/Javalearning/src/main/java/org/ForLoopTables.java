package org;

public class ForLoopTables {
    public static void main(String[] args) {
        int i = 10;

        for (int a = 1; a <= 10; a++) {
            System.out.println(i + "*" + a + "=" + (i * a));
            {

            }
        }
    }
}

