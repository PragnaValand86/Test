package org;

public class ForLoop {
    public static void main(String[] args) {
        int a =20;
        System.out.println("Even Numbers");
        {
            for (int n = 1; n <=20; n++) {
                if (n % 2 == 0)
                    System.out.println(n);
                }
            System.out.println("Odd Numbers");
                        for (int n = 1; n <= 20; n++) {
                            if (n % 2 != 0) {
                                System.out.println(n);
                            }
                        }

                    }
                }


            }






