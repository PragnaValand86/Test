package org;

public class WhileLoopTableOf9 {
    public static void main(String[] args) {
        int a = 9;
        int b = 1;

        while (b <= 10){

            System.out.println(a+"*" + "=" + (a*b));
            b++;

        }
    }
}
