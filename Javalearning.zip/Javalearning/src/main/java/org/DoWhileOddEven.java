package org;

public class DoWhileOddEven {
    public static void main(String[] args) {
        int x = 10;
        int y = 0;
        System.out.println("Even Numbers");

        do {
            System.out.println(y + "");
            y += 2;
        } while (y <= 10) ;

        System.out.println("Odd Numbers");
        y=1;
        do {
            System.out.println(y + "");
            y +=2;
        } while(y <=10);
        }

            }













