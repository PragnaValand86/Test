package org;

public class WhileLoop {
    public static void main(String[] args) {
        int i = 20;
        int n = 1;
        System.out.println("evn numbers");
        {
            while (n <= 20) {
                n++;

                if (n % 2 == 0) {
                    System.out.println(n);
                }



                    }

                }
            }
        }

















