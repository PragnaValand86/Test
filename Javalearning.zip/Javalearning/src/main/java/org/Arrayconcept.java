package org;

import java.sql.SQLOutput;

public class Arrayconcept {
    public static void main(String[] args) {
        int a=10;
            a=20;
            a=30;

        System.out.println(a);
        int i[] = new int[4];

        i[0] = 10;
        i[1] = 20;
        i[2] = 30;
        i[3] = 40;

        System.out.println(i[1]);
        System.out.println(i.length); {
    }
}
}
